<?php $__env->startSection('content'); ?>


	<?php echo $__env->make('plantilla.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('plantilla.canvas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-proximamente">
    <div class="banner-1"><img src="<?php echo e(asset('clientlibs/img/premios-1.png')); ?>" alt="Engie"></div>
    <div class="banner-2"><img src="<?php echo e(asset('clientlibs/img/premios-2.png')); ?>" alt="Engie"></div>
    <div class="clearfix"></div>
</div>

	<?php echo $__env->make('plantilla.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	

<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/papa/proyectos/engie/resources/views/premios.blade.php ENDPATH**/ ?>