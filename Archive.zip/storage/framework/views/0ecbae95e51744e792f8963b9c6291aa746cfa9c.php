<?php $__env->startSection('content'); ?>


	<?php echo $__env->make('plantilla.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('plantilla.canvas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="faqs">
<div class="title">
<h2>Términos y condiciones</h2>
</div>
<div class="content">
<h2>Concurso "Engie te premia"</h2>


<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam id pulvinar neque. Morbi gravida leo mi, non ullamcorper urna hendrerit non. Sed vestibulum pellentesque dolor ac hendrerit. Mauris dapibus mi urna, eu porttitor risus feugiat blandit. Fusce porttitor justo eu risus congue, nec porttitor mi tristique. Quisque massa libero, egestas eget maximus in, efficitur interdum lorem. Vivamus pharetra erat vitae magna sollicitudin scelerisque. Nullam nec euismod turpis, sit amet maximus ante. Sed eget varius lacus.</p>

<p>Donec accumsan, nunc non suscipit vehicula, metus libero tempor mi, at scelerisque est tortor ac metus. Suspendisse potenti. Integer non tempor nisi, ac dapibus dolor. Proin congue hendrerit tincidunt. Cras suscipit nulla quis turpis euismod volutpat. Donec eget elementum ipsum. Nunc neque ipsum, semper eget rhoncus vitae, varius accumsan velit. Donec pharetra elementum purus vel pretium. Cras iaculis, nisl eget egestas cursus, odio arcu imperdiet dolor, sed maximus quam nunc sed nulla. Nunc porta lacinia molestie. Mauris convallis rhoncus risus nec elementum.</p>

<p>Donec eget purus cursus, fermentum risus sed, porta urna. Nulla finibus ex est. Cras dignissim lorem in eros finibus, in mollis quam ultricies. Etiam venenatis, ante id consectetur mollis, libero neque pulvinar augue, ut placerat justo turpis vel velit. Suspendisse quis tempor diam. Morbi tincidunt libero id rutrum dapibus. Aenean a nisi eleifend, scelerisque tortor sit amet, scelerisque nibh. Nullam eu congue sapien. In tempor facilisis velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>

<p>Fusce volutpat rutrum elit, eu bibendum risus tristique tempor. Sed sodales iaculis odio, quis porttitor turpis ullamcorper nec. Fusce nec gravida ante, ac egestas elit. Sed eget nulla nec nisl dictum vestibulum ut in dui. Vestibulum efficitur, erat sit amet sollicitudin posuere, augue mauris molestie est, at egestas urna est et metus. Cras viverra tristique risus eu facilisis. Fusce eu arcu vitae arcu suscipit semper vitae vestibulum risus. Nam ligula sem, interdum a tellus in, ornare porttitor tortor. Donec et euismod sem, et vestibulum purus. Suspendisse vel tellus auctor nibh placerat condimentum. Morbi a pretium orci. Morbi tristique ipsum sem, vel ullamcorper neque accumsan eget. Morbi iaculis ligula nec lorem consectetur, viverra vestibulum leo ullamcorper.</p>

<p>Vestibulum fringilla dui ac neque posuere maximus. Quisque ut elementum leo. Mauris volutpat in eros sed elementum. Donec semper justo quis purus rhoncus sagittis. Duis laoreet, eros vel vehicula ultrices, risus dui commodo magna, id congue tellus nulla non turpis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed non luctus risus. In erat ante, interdum in dui non, convallis lobortis magna. Vestibulum neque ex, facilisis vitae diam id, egestas consequat arcu.</p>

<p>In hac habitasse platea dictumst. Sed purus risus, molestie eget turpis id, tincidunt vestibulum urna. Suspendisse tincidunt est nec dolor dapibus, ut suscipit lorem efficitur. Pellentesque maximus dignissim blandit. Quisque ut dapibus libero. Sed eleifend scelerisque massa, vel elementum lorem suscipit non. Mauris et ullamcorper metus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Donec venenatis blandit quam vitae fringilla. Vestibulum efficitur tortor in libero dictum, ut tristique tortor tincidunt. Duis eget gravida risus. Sed nec mauris et neque consectetur venenatis.</p>

<p>Ut non metus interdum, sagittis tellus ac, malesuada risus. Morbi fringilla cursus malesuada. Cras in sem cursus, malesuada diam a, sodales nibh. Ut fermentum magna ac maximus rutrum. Morbi eu viverra quam, egestas pulvinar risus. Aliquam egestas elit at arcu commodo, ullamcorper consequat magna ullamcorper. Vivamus ac nunc quam. Aenean ac elementum tortor. In blandit blandit enim sit amet luctus. Etiam mauris lorem, porta nec ante sit amet, varius pharetra massa. </p>


</div>
</div>

	<?php echo $__env->make('plantilla.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/papa/proyectos/engie/resources/views/terminos.blade.php ENDPATH**/ ?>