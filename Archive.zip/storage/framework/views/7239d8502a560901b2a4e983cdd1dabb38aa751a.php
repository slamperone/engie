<?php $__env->startSection('content'); ?>


	<?php echo $__env->make('plantilla.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('plantilla.canvas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('plantilla.proximamente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('plantilla.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('plantilla.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	

<div id="bienvenida" class="modal">

		<img src="<?php echo e(asset('clientlibs/img/bienvenido.png')); ?>" width="100%" alt="">
		
</div>


<script type="text/javascript">
	
$("#bienvenida").modal({
                    fadeDuration: 100
              });


</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/papa/proyectos/engie/resources/views/home.blade.php ENDPATH**/ ?>