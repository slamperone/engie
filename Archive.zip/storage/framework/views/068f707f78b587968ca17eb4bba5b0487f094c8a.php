<?php $__env->startSection('content'); ?>


	<?php echo $__env->make('plantilla.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




	<?php echo $__env->make('plantilla.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->make('plantilla.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	

<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/papa/proyectos/engie/resources/views/concurso.blade.php ENDPATH**/ ?>