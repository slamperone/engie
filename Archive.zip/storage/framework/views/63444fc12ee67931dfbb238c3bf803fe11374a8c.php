<footer>
    <div class="content">
        <div class="footer-logo">
            <div class="photo">
                <a href="<?php echo e(url('/')); ?>">
                    <div class="logo"><img src="<?php echo e(asset('clientlibs/img/engie.png')); ?>" alt="Engie"></div>
                </a>
            </div>
        </div>
        <div class="footer-izq">
            <p>Copyright © 2019, todos los derechos reservados</p>
        </div>
          <div class="footer-der">
            <div class="menu">
                <ul>
                    <li class="btn"><a href="<?php echo e(url('/')); ?>">Inicio I</a></li>
                    <li class="btn"><a href="<?php echo e(url('/concurso')); ?>">Concurso I</a></li>
                    <!--li class="btn"><a href="<?php echo e(url('/instrucciones')); ?>">Instrucciones I</a></li-->
                    <li class="btn"><a href="<?php echo e(url('/premios')); ?>">Premios I</a></li>
                    <li class="btn"><a href="<?php echo e(url('/bases')); ?>">Bases I</a></li>
                    <li class="btn"><a href="<?php echo e(url('/faqs')); ?>">Faqs I</a></li>
                    <li class="btn"><a href="<?php echo e(url('aviso-de-privacidad')); ?>">Aviso de privacidad</a></li>
                    <div class="clearfix"></div>
                </ul>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="clearfix"></div>
</footer><?php /**PATH /Users/papa/proyectos/engie/resources/views/plantilla/footer.blade.php ENDPATH**/ ?>