<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">

</head>
<body>
<div style="width: 600px; padding: 0 0 60px 0; border-bottom: 3px solid #F5BA27;">	
	<div style="width: 580px; height: 80px; padding: 20px 0 0 20px;">
		<img src="https://engietepremia.com.mx/clientlibs/img/engie.png" width="200">
	</div>
	<h2 style="margin: 20px 0 60px; font-family: Gotham, 'Helvetica Neue', Helvetica, Arial, 'sans-serif'; font-size: 20px;">Hola <?php echo e($nombre); ?>, gracias por registrarte en <strong>ENGIE te premia</strong></h2>    
    <p style="font-family: Gotham, 'Helvetica Neue', Helvetica, Arial, 'sans-serif'">Tu numero de folio es: <b><?php echo e($folio); ?></b>, debes conservarlo para reclamar tu premio. <br />Al ser este un email de confirmación no es necesario que lo respondas te deseamos ¡Mucha suerte"</p>
</div>

</body>
</html><?php /**PATH /Users/papa/proyectos/engie/resources/views/mail/registro.blade.php ENDPATH**/ ?>