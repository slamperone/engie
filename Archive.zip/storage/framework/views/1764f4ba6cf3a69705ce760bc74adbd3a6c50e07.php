<div class="feed-3cubes">
    <div class="title">
        <div class="content-text">
            <h2>¿Cómo participar?</h2>
            <p>Tienes que ser usuario de mi cuenta para participar en este concurso. Si aún no lo eres ingresa aquí.</p>
        </div>
    </div>
    <div class="content">
        <div class="title">
            <h2>Pasos</h2>
        </div>
        <div class="content-boxes">
            <div class="box">
                <div class="logo">1</div>
                <h2>Llena el formulario de registro que aparece abajo.</h2>
            </div>
            <div class="box">
                <div class="logo">2</div>
                <h2>Contesta correctamente nuestra trivia.</h2>
            </div>
            <div class="box">
                <div class="logo">3</div>
                <h2>Sé uno de nuestros 683 ganadores.</h2>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div><?php /**PATH /Users/papa/proyectos/engie/resources/views/plantilla/feed.blade.php ENDPATH**/ ?>