<div class="content-proximamente">
    <div class="stage-home">
    <div class="right">
        <div class="box-1">A partir del</div>
        <div class="box-2">3 de Junio</div>
        <div class="box-3">ENGIE te premia</div>
        <div class="box-4">
            <img src="{{ asset('clientlibs/img/pasos-stage.jpg') }}" alt="Engie">
        </div>
        <div class="box-5"><b>ENGIE</b>, mucho más que gas natural</div>
        <div class="box-4">
            <img src="{{ asset('clientlibs/img/line-stage.jpg') }}" alt="Engie">
        </div>
        <div class="box-6">Aviso Profeco PFC. C.A./00737-2019, conoce las bases del concurso en www.engietepremia.com.mx </div>
    </div>
    <div class="left">
        <img src="{{ asset('clientlibs/img/photo-stage.jpg') }}" alt="Engie">
    </div>
</div>
</div>