@extends('plantilla.master')
@section('content')


	@include('plantilla.nav')




	@include('plantilla.form')

	@include('plantilla.footer')
	

@endsection

